# hair_yolov7_segmentation > 2023-12-04 8:39pm
https://universe.roboflow.com/manish-kumar-ytl7z/hair_yolov7_segmentation

Provided by a Roboflow user
License: CC BY 4.0

