# iphone_scratch_yolov3_v5 > 2023-12-07 4:00pm
https://universe.roboflow.com/manish-kumar-ytl7z/iphone_scratch_yolov3_v5

Provided by a Roboflow user
License: CC BY 4.0

