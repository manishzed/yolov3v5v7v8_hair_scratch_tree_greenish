# iphone_hair_scratch_dataset_merged > 2023-12-08 4:23pm
https://universe.roboflow.com/manish-kumar-ytl7z/iphone_hair_scratch_dataset_merged

Provided by a Roboflow user
License: CC BY 4.0

